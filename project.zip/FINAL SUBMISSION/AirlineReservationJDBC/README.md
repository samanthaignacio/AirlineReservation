CS 157A Term Project
Samantha Ignacio
Katrina Festejo
Yen Huynh

Green Airline Reservation

- Use terminal to create database and load data from text files using the schema SQL file
- Use MySQL Workbench to add stored procedures to the database
- Use Java application to run the Airline Reservation System